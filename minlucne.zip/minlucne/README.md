Hello , welcome to my lucene project !
I use 6 kinds of analyzers as well as 2 approaches of scoring methods .
just type:

"java -jar minlucne.jar"

Then choose your analyzer with the number 1 2 3 4 5 6 ,and similarity 1 2 .
Then you can see all the results of scores compared with each other .
Have a nice day !
